with open('/home/ubuntu/lty/H-SAM/lists/fxa/train.txt', 'w') as f:
    for i in range(1, 6826):
        f.write(f"{i}\n")
