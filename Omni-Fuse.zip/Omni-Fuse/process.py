import nibabel as nib

img = nib.load("/home/ubuntu/lty/H-SAM/Predictions/predictions/batch_1_gt.nii.gz")  # 直接加载.gz文件
data = img.get_fdata()
print("直接加载.nii.gz的形状:", data.shape)