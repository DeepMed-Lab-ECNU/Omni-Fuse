import os
import numpy as np
from PIL import Image
import glob

images_folder = 'data/images'
labels_folder = 'data/labels'
output_folder = 'data/train_npz'

if not os.path.exists(output_folder):
    os.makedirs(output_folder)
image_paths = sorted(glob.glob(os.path.join(images_folder, '*.png')))
label_paths = sorted(glob.glob(os.path.join(labels_folder, '*.png')))
for img_path, lbl_path in zip(image_paths, label_paths):
    img = Image.open(img_path).convert('RGB')
    img_resized = img.resize((224, 224))
    img_array = np.array(img_resized) / 127.5 - 1
    img_array = img_array[:, :, 0]
    lbl = Image.open(lbl_path).convert('L')
    lbl_resized = lbl.resize((224, 224))
    lbl_array = np.array(lbl_resized)
    base_name = os.path.splitext(os.path.basename(img_path))[0]
    npz_filename = os.path.join(output_folder, f'{base_name}.npz')
    np.savez(npz_filename, image=img_array.astype(np.float32), label=lbl_array.astype(np.float32))

    print(f"processed and saved：{npz_filename}")