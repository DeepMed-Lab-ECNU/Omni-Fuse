import numpy as np


data = np.load('/home/russ/ava/Dual-Stream-MHSI/processed_npz/030406-20x-roi1_slice000.npz')


print("np.array: ", data.files)
for array_name in data.files:
    array_data = data[array_name]
    print(f"{array_name} shape: {array_data.shape}")
