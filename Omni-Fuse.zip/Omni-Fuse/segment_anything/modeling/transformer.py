# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.

# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.

import torch
from torch import Tensor, nn

import math
from typing import Tuple, Type

from .common import MLPBlock
from typing import Optional


# class TwoWayTransformer(nn.Module):
#     def __init__(
#         self,
#         depth: int,
#         embedding_dim: int,
#         num_heads: int,
#         mlp_dim: int,
#         activation: Type[nn.Module] = nn.ReLU,
#         attention_downsample_rate: int = 2,
#     ) -> None:
#         """
#         A transformer decoder that attends to an input image using
#         queries whose positional embedding is supplied.
#
#         Args:
#           depth (int): number of layers in the transformer
#           embedding_dim (int): the channel dimension for the input embeddings
#           num_heads (int): the number of heads for multihead attention. Must
#             divide embedding_dim
#           mlp_dim (int): the channel dimension internal to the MLP block
#           activation (nn.Module): the activation to use in the MLP block
#         """
#         super().__init__()
#         self.depth = depth
#         self.embedding_dim = embedding_dim
#         self.num_heads = num_heads
#         self.mlp_dim = mlp_dim
#         self.layers = nn.ModuleList()
#
#         for i in range(depth):
#             self.layers.append(
#                 TwoWayAttentionBlock(
#                     embedding_dim=embedding_dim,
#                     num_heads=num_heads,
#                     mlp_dim=mlp_dim,
#                     activation=activation,
#                     attention_downsample_rate=attention_downsample_rate,
#                     skip_first_layer_pe=(i == 0),
#                 )
#             )
#
#         self.final_attn_token_to_image = Attention(
#             embedding_dim, num_heads, downsample_rate=attention_downsample_rate
#         )
#         self.norm_final_attn = nn.LayerNorm(embedding_dim)
#
#     def forward(
#         self,
#         image_embedding: Tensor,
#         image_pe: Tensor,
#         point_embedding: Tensor,
#         mask_feat = None
#     ) -> Tuple[Tensor, Tensor]:
#         """
#         Args:
#           image_embedding (torch.Tensor): image to attend to. Should be shape
#             B x embedding_dim x h x w for any h and w.
#           image_pe (torch.Tensor): the positional encoding to add to the image. Must
#             have the same shape as image_embedding.
#           point_embedding (torch.Tensor): the embedding to add to the query points.
#             Must have shape B x N_points x embedding_dim for any N_points.
#
#         Returns:
#           torch.Tensor: the processed point_embedding
#           torch.Tensor: the processed image_embedding
#         """
#         # BxCxHxW -> BxHWxC == B x N_image_tokens x C
#         bs, c, h, w = image_embedding.shape
#         image_embedding = image_embedding.flatten(2).permute(0, 2, 1)
#         image_pe = image_pe.flatten(2).permute(0, 2, 1)
#
#         # Prepare queries
#         queries = point_embedding
#         keys = image_embedding
#
#         # Apply transformer blocks and final layernorm
#         for layer in self.layers:
#             queries, keys = layer(
#                 queries=queries,
#                 keys=keys,
#                 query_pe=point_embedding,
#                 key_pe=image_pe
#             )
#
#         # Apply the final attenion layer from the points to the image
#         q = queries + point_embedding
#         k = keys + image_pe
#         attn_out = self.final_attn_token_to_image(q=q, k=k, v=keys)
#         queries = queries + attn_out
#         queries = self.norm_final_attn(queries)
#
#         return queries, keys, attn_out


class TwoWayTransformer2(nn.Module):
    def __init__(
        self,
        depth: int,
        embedding_dim: int,
        num_heads: int,
        mlp_dim: int,
        activation: Type[nn.Module] = nn.ReLU,
        attention_downsample_rate: int = 2,
    ) -> None:
        super().__init__()
        self.depth = depth
        self.embedding_dim = embedding_dim
        self.num_heads = num_heads
        self.mlp_dim = mlp_dim
        self.layers = nn.ModuleList()

        for i in range(depth):
            self.layers.append(
                TwoWayAttentionBlock2(
                    embedding_dim=embedding_dim,
                    num_heads=num_heads,
                    mlp_dim=mlp_dim,
                    activation=activation,
                    attention_downsample_rate=attention_downsample_rate,
                    skip_first_layer_pe=(i == 0),
                )
            )

        self.final_attn_token_to_image = Attention(
            embedding_dim, num_heads, downsample_rate=attention_downsample_rate
        )
        self.norm_final_attn = nn.LayerNorm(embedding_dim)

    def forward(
        self,
        image_embedding: Tensor,
        image_pe: Tensor,
        point_embedding: Tensor,
        mask_feat: Tensor = None  # Ensure mask_feat is optional here
    ) -> Tuple[Tensor, Tensor, Tensor]:  # Return three values for mask decoder
        # BxCxHxW -> BxHWxC == B x N_image_tokens x C
        bs, c, h, w = image_embedding.shape
        image_embedding = image_embedding.flatten(2).permute(0, 2, 1)
        image_pe = image_pe.flatten(2).permute(0, 2, 1)

        # Prepare queries
        queries = point_embedding
        keys = image_embedding

        # Apply transformer blocks and final layernorm
        for layer in self.layers:
            queries, keys = layer(
                queries=queries,
                keys=keys,
                query_pe=point_embedding,
                key_pe=image_pe,
                mask_feat=mask_feat  # Pass mask_feat to each layer
            )

        # Apply the final attention layer from the points to the image
        q = queries + point_embedding
        k = keys + image_pe
        attn_out = self.final_attn_token_to_image(q=q, k=k, v=keys)
        queries = queries + attn_out
        queries = self.norm_final_attn(queries)

        # Return three values to match mask decoder expectations
        return queries, keys, attn_out


import torch
from torch import Tensor, nn
import math
from typing import Tuple, Type, Optional


# Helper function to get activation
def _get_activation_fn(activation: str):
    """Return an activation function given a string."""
    if activation == "relu":
        return nn.ReLU()
    elif activation == "gelu":
        return nn.GELU()
    elif activation == "elu":
        return nn.ELU()
    else:
        raise RuntimeError(f"Activation {activation} not supported")


# Attention class (unchanged)
class Attention(nn.Module):
    def __init__(self, embedding_dim: int, num_heads: int, downsample_rate: int = 1, dropout=0.0) -> None:
        super().__init__()
        self.embedding_dim = embedding_dim
        self.internal_dim = embedding_dim // downsample_rate
        self.num_heads = num_heads
        assert self.internal_dim % num_heads == 0, "num_heads must divide embedding_dim."
        self.q_proj = nn.Linear(embedding_dim, self.internal_dim)
        self.k_proj = nn.Linear(embedding_dim, self.internal_dim)
        self.v_proj = nn.Linear(embedding_dim, self.internal_dim)
        self.out_proj = nn.Linear(self.internal_dim, embedding_dim)
        self.dropout = nn.Dropout(dropout)

    def _separate_heads(self, x: Tensor, num_heads: int) -> Tensor:
        b, n, c = x.shape
        x = x.reshape(b, n, num_heads, c // num_heads)
        return x.transpose(1, 2)

    def _recombine_heads(self, x: Tensor) -> Tensor:
        b, n_heads, n_tokens, c_per_head = x.shape
        x = x.transpose(1, 2)
        return x.reshape(b, n_tokens, n_heads * c_per_head)

    def forward(self, q: Tensor, k: Tensor, v: Tensor) -> Tensor:
        q = self.q_proj(q)
        k = self.k_proj(k)
        v = self.v_proj(v)
        q = self._separate_heads(q, self.num_heads)
        k = self._separate_heads(k, self.num_heads)
        v = self._separate_heads(v, self.num_heads)
        _, _, _, c_per_head = q.shape
        attn = q @ k.permute(0, 1, 3, 2)
        attn = attn / math.sqrt(c_per_head)
        attn = torch.softmax(attn, dim=-1)
        out = attn @ v
        out = self._recombine_heads(out)
        out = self.out_proj(out)
        return out


# TwoWayAttentionBlock (unchanged)
class TwoWayAttentionBlock(nn.Module):
    def __init__(self, embedding_dim: int, num_heads: int, mlp_dim: int = 2048, activation: Type[nn.Module] = nn.ReLU,
                 attention_downsample_rate: int = 2, skip_first_layer_pe: bool = False) -> None:
        super().__init__()
        self.self_attn = Attention(embedding_dim, num_heads)
        self.norm1 = nn.LayerNorm(embedding_dim)
        self.cross_attn_token_to_image = Attention(embedding_dim, num_heads, downsample_rate=attention_downsample_rate)
        self.norm2 = nn.LayerNorm(embedding_dim)
        self.mlp = nn.Sequential(nn.Linear(embedding_dim, mlp_dim), activation(), nn.Linear(mlp_dim, embedding_dim))
        self.norm3 = nn.LayerNorm(embedding_dim)
        self.norm4 = nn.LayerNorm(embedding_dim)
        self.cross_attn_image_to_token = Attention(embedding_dim, num_heads, downsample_rate=attention_downsample_rate)
        self.skip_first_layer_pe = skip_first_layer_pe

    def forward(self, queries: Tensor, keys: Tensor, query_pe: Tensor, key_pe: Tensor) -> Tuple[Tensor, Tensor]:
        q = queries + query_pe
        k = keys + key_pe
        attn_out = self.cross_attn_token_to_image(q=q, k=k, v=keys)
        queries = queries + attn_out
        queries = self.norm2(queries)
        if self.skip_first_layer_pe:
            queries = self.self_attn(q=queries, k=queries, v=queries)
        else:
            q = queries + query_pe
            attn_out = self.self_attn(q=q, k=q, v=queries)
            queries = queries + attn_out
        queries = self.norm1(queries)
        mlp_out = self.mlp(queries)
        queries = queries + mlp_out
        queries = self.norm3(queries)
        q = queries + query_pe
        k = keys + key_pe
        attn_out = self.cross_attn_image_to_token(q=k, k=q, v=queries)
        keys = keys + attn_out
        keys = self.norm4(keys)
        return queries, keys


# SSRL-related classes
class spectral_mamba(nn.Module):
    def __init__(self, hidden_feature, d_state=16, d_conv=4, expand=2):
        super().__init__()
        self.mamba_1D = nn.Sequential(nn.Linear(hidden_feature, hidden_feature * expand), nn.ReLU(),
                                      nn.Linear(hidden_feature * expand, hidden_feature))  # Simplified placeholder

    def forward(self, x):
        x_forward = x
        x_backward = x.flip(dims=[1])
        forward_feature = self.mamba_1D(x_forward)
        backward_feature = self.mamba_1D(x_backward)
        out = torch.cat([forward_feature, backward_feature], dim=2)
        return out


class SSRL(nn.Module):
    def __init__(self, in_channels, hidden_feature, spe_reduction, d_state, d_conv, expand, dim_reduction=4,
                 kernel_size=1):
        super().__init__()
        self.dim_reduction = dim_reduction
        self.spe_reduction = spe_reduction
        self.conv = nn.Conv2d(in_channels, in_channels, kernel_size=3, stride=1, padding=1)

        if hidden_feature % in_channels != 0:
            raise ValueError(
                f"hidden_feature ({hidden_feature}) must be divisible by in_channels ({in_channels}) for depthwise convolution")
        self.depthwiseconv = nn.Conv2d(in_channels=in_channels, out_channels=hidden_feature, kernel_size=spe_reduction,
                                       stride=1, padding=spe_reduction // 2, groups=in_channels)
        self.attention = spectral_mamba(hidden_feature=hidden_feature, d_state=d_state, d_conv=d_conv, expand=expand)
        self.spectral_ffn = nn.Sequential(nn.BatchNorm1d(hidden_feature * 2),
                                          nn.Conv1d(hidden_feature * 2, hidden_feature * 2, kernel_size=kernel_size,
                                                    stride=1,
                                                    padding=kernel_size // 2 if kernel_size != 1 else 0),
                                          nn.GELU(),
                                          nn.Conv1d(hidden_feature * 2, hidden_feature * 2, kernel_size=kernel_size,
                                                    stride=1,
                                                    padding=kernel_size // 2 if kernel_size != 1 else 0))

    def forward(self, x):
        from einops import rearrange
        b, c, s, h, w = x.shape
        x = rearrange(x, 'b c s h w -> (b s) c h w')
        if c != 1:
            x = self.conv(x)
        x = self.depthwiseconv(x)
        h_, w_ = x.shape[-2], x.shape[-1]
        x1 = rearrange(x, '(b s) c h w -> (b h w) s c', s=s)
        x1 = self.attention(x1)
        x1 = rearrange(x1, '(b h w) s c -> (b h w) c s', b=b, h=h_, w=w_, s=s)
        o = self.spectral_ffn(x1) + x1
        o = rearrange(o, '(b h w) c s -> b c s h w', b=b, h=h_, w=w_)
        return o


# Cross Attention Layer
class CrossAttentionLayer(nn.Module):
    def __init__(self, d_model, nhead, dropout=0.0, activation="relu", normalize_before=False):
        super().__init__()
        self.multihead_attn = nn.MultiheadAttention(d_model, nhead, dropout=dropout)
        self.norm = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)
        self.activation = _get_activation_fn(activation)
        self.normalize_before = normalize_before
        self.nhead = nhead  # Store nhead for debugging
        self.d_model = d_model
        self._reset_parameters()

    def _reset_parameters(self):
        for p in self.parameters():
            if p.dim() > 1:
                nn.init.xavier_uniform_(p)

    def with_pos_embed(self, tensor, pos: Optional[Tensor]):
        return tensor if pos is None else tensor + pos

    def forward(self, tgt, memory, memory_mask: Optional[Tensor] = None,
                memory_key_padding_mask: Optional[Tensor] = None,
                pos: Optional[Tensor] = None, query_pos: Optional[Tensor] = None):
        # Debug shapes

        if self.normalize_before:
            tgt2 = self.norm(tgt)
            tgt2 = self.multihead_attn(query=self.with_pos_embed(tgt2, query_pos),
                                       key=self.with_pos_embed(memory, pos),
                                       value=memory, attn_mask=memory_mask,
                                       key_padding_mask=memory_key_padding_mask)[0]
            tgt = tgt + self.dropout(tgt2)
        else:
            tgt2 = self.multihead_attn(query=self.with_pos_embed(tgt, query_pos),
                                       key=self.with_pos_embed(memory, pos),
                                       value=memory, attn_mask=memory_mask,
                                       key_padding_mask=memory_key_padding_mask)[0]
            tgt = tgt + self.dropout(tgt2)
            tgt = self.norm(tgt)
        return tgt


# Modified TwoWayTransformer with SSRL and Cross-Attention
class TwoWayTransformer(nn.Module):
    def __init__(self, depth: int, embedding_dim: int, num_heads: int, mlp_dim: int,
                 ssrl_hidden_feature: int = None, ssrl_spe_reduction: int = 4,
                 d_state: int = 16, d_conv: int = 4, expand: int = 2, cross_d_model: int = 256, cross_nhead: int = 8,
                 activation: Type[nn.Module] = nn.ReLU, attention_downsample_rate: int = 2) -> None:
        super().__init__()
        self.depth = depth
        self.embedding_dim = embedding_dim
        self.num_heads = num_heads
        self.mlp_dim = mlp_dim
        self.layers = nn.ModuleList()
        for i in range(depth):
            self.layers.append(TwoWayAttentionBlock(embedding_dim=embedding_dim, num_heads=num_heads, mlp_dim=mlp_dim,
                                                    activation=activation,
                                                    attention_downsample_rate=attention_downsample_rate,
                                                    skip_first_layer_pe=(i == 0)))
        self.final_attn_token_to_image = Attention(embedding_dim, num_heads, downsample_rate=attention_downsample_rate)
        self.norm_final_attn = nn.LayerNorm(embedding_dim)

        # Set ssrl_hidden_feature to embedding_dim by default if not specified
        ssrl_hidden_feature = embedding_dim if ssrl_hidden_feature is None else ssrl_hidden_feature

        # SSRL integration with dynamic in_channels
        self.ssrl = SSRL(in_channels=embedding_dim, hidden_feature=ssrl_hidden_feature,
                         spe_reduction=ssrl_spe_reduction, d_state=d_state, d_conv=d_conv, expand=expand)

        # Cross-attention for merging
        self.cross_attention = CrossAttentionLayer(d_model=cross_d_model, nhead=cross_nhead)
        self.transformer_to_cross = nn.Linear(embedding_dim, cross_d_model)
        self.ssrl_to_cross = nn.Linear(ssrl_hidden_feature * 2, cross_d_model)
        # Project back to embedding_dim if needed
        self.cross_to_embedding = nn.Linear(cross_d_model, embedding_dim) if cross_d_model != embedding_dim else nn.Identity()

    def forward(self, image_embedding: Tensor, image_pe: Tensor, point_embedding: Tensor, mask_feat=None) -> Tuple[Tensor, Tensor, Tensor]:
        # Transformer processing
        bs, c, h, w = image_embedding.shape
        image_embedding_flat = image_embedding.flatten(2).permute(0, 2, 1)  # [B, H*W, C]
        image_pe_flat = image_pe.flatten(2).permute(0, 2, 1)  # [B, H*W, C]
        queries = point_embedding  # [B, N_points, C]
        keys = image_embedding_flat  # [B, H*W, C]
        for layer in self.layers:
            queries, keys = layer(queries=queries, keys=keys, query_pe=point_embedding, key_pe=image_pe_flat)
        q = queries + point_embedding
        k = keys + image_pe_flat
        attn_out = self.final_attn_token_to_image(q=q, k=k, v=keys)
        transformer_queries = queries + attn_out
        transformer_queries = self.norm_final_attn(transformer_queries)  # [B, N_points, embedding_dim]

        # SSRL processing
        ssrl_input = image_embedding.unsqueeze(2)  # Add spectral dim: [B, embedding_dim, 1, H, W]
        ssrl_output = self.ssrl(ssrl_input)  # [B, hidden_feature*2, S, H, W]
        b, c_ssrl, s, h_ssrl, w_ssrl = ssrl_output.shape
        ssrl_output = ssrl_output.view(b, c_ssrl * s, h_ssrl * w_ssrl).permute(0, 2, 1)  # [B, H*W, C*S]

        # Adjust dimensions for cross-attention
        transformer_output = self.transformer_to_cross(transformer_queries)  # [B, N_points, cross_d_model]
        ssrl_output = self.ssrl_to_cross(ssrl_output)  # [B, H*W, cross_d_model]

        # Debug shapes before cross-attention

        # Transpose to sequence-first format for nn.MultiheadAttention
        transformer_output = transformer_output.permute(1, 0, 2)  # [N_points, B, cross_d_model]
        ssrl_output = ssrl_output.permute(1, 0, 2)  # [H*W, B, cross_d_model]

        # Cross-attention
        fused_output = self.cross_attention(tgt=transformer_output, memory=ssrl_output)  # [N_points, B, cross_d_model]

        # Transpose back to batch-first format and project to embedding_dim
        fused_output = fused_output.permute(1, 0, 2)  # [B, N_points, cross_d_model]
        fused_output = self.cross_to_embedding(fused_output)  # [B, N_points, embedding_dim]

        # Return three values: processed queries, processed keys, and attention output
        return fused_output, keys, attn_out
# class TwoWayAttentionBlock(nn.Module):
#     def __init__(
#         self,
#         embedding_dim: int,
#         num_heads: int,
#         mlp_dim: int = 2048,
#         activation: Type[nn.Module] = nn.ReLU,
#         attention_downsample_rate: int = 2,
#         skip_first_layer_pe: bool = False,
#     ) -> None:
#         """
#         A transformer block with four layers: (1) self-attention of sparse
#         inputs, (2) cross attention of sparse inputs to dense inputs, (3) mlp
#         block on sparse inputs, and (4) cross attention of dense inputs to sparse
#         inputs.
#
#         Arguments:
#           embedding_dim (int): the channel dimension of the embeddings
#           num_heads (int): the number of heads in the attention layers
#           mlp_dim (int): the hidden dimension of the mlp block
#           activation (nn.Module): the activation of the mlp block
#           skip_first_layer_pe (bool): skip the PE on the first layer
#         """
#         super().__init__()
#         self.self_attn = Attention(embedding_dim, num_heads)
#         self.norm1 = nn.LayerNorm(embedding_dim)
#
#         self.cross_attn_token_to_image = Attention(
#             embedding_dim, num_heads, downsample_rate=attention_downsample_rate
#         )
#         self.norm2 = nn.LayerNorm(embedding_dim)
#
#         self.mlp = MLPBlock(embedding_dim, mlp_dim, activation)
#         self.norm3 = nn.LayerNorm(embedding_dim)
#
#         self.norm4 = nn.LayerNorm(embedding_dim)
#         self.cross_attn_image_to_token = Attention(
#             embedding_dim, num_heads, downsample_rate=attention_downsample_rate
#         )
#
#         self.skip_first_layer_pe = skip_first_layer_pe
#
#     def forward(
#         self, queries: Tensor, keys: Tensor, query_pe: Tensor, key_pe: Tensor
#     ) -> Tuple[Tensor, Tensor]:
#
#         # Cross attention block, tokens attending to image embedding
#         q = queries + query_pe
#         k = keys + key_pe
#         attn_out = self.cross_attn_token_to_image(q=q, k=k, v=keys)
#         queries = queries + attn_out
#         queries = self.norm2(queries)
#
#         # Self attention block
#         if self.skip_first_layer_pe:
#             queries = self.self_attn(q=queries, k=queries, v=queries)
#         else:
#             q = queries + query_pe
#             attn_out = self.self_attn(q=q, k=q, v=queries)
#             queries = queries + attn_out
#         queries = self.norm1(queries)
#
#         # MLP block
#         mlp_out = self.mlp(queries)
#         queries = queries + mlp_out
#         queries = self.norm3(queries)
#
#         # Cross attention block, image embedding attending to tokens
#         q = queries + query_pe
#         k = keys + key_pe
#         attn_out = self.cross_attn_image_to_token(q=k, k=q, v=queries)
#         keys = keys + attn_out
#         keys = self.norm4(keys)
#
#         return queries, keys

class TwoWayAttentionBlock2(nn.Module):
    def __init__(
        self,
        embedding_dim: int,
        num_heads: int,
        mlp_dim: int = 2048,
        activation: Type[nn.Module] = nn.ReLU,
        attention_downsample_rate: int = 2,
        skip_first_layer_pe: bool = False,
    ) -> None:
        """
        A transformer block with four layers: (1) self-attention of sparse
        inputs, (2) cross attention of sparse inputs to dense inputs, (3) mlp
        block on sparse inputs, and (4) cross attention of dense inputs to sparse
        inputs.

        Arguments:
          embedding_dim (int): the channel dimension of the embeddings
          num_heads (int): the number of heads in the attention layers
          mlp_dim (int): the hidden dimension of the mlp block
          activation (nn.Module): the activation of the mlp block
          skip_first_layer_pe (bool): skip the PE on the first layer
        """
        super().__init__()
        self.self_attn = Attention(embedding_dim, num_heads)
        self.norm1 = nn.LayerNorm(embedding_dim)

        self.cross_attn_token_to_image = Attention2(embedding_dim, num_heads)
        self.norm2 = nn.LayerNorm(embedding_dim)

        self.mlp = MLPBlock(embedding_dim, mlp_dim, activation)
        self.norm3 = nn.LayerNorm(embedding_dim)

        self.norm4 = nn.LayerNorm(embedding_dim)
        # self.cross_attn_image_to_token = Attention(
        #     embedding_dim, num_heads, downsample_rate=attention_downsample_rate
        # )
        self.cross_attn_image_to_token = Attention2(embedding_dim, num_heads)

        self.skip_first_layer_pe = skip_first_layer_pe
        self.dropout = nn.Dropout(0.2)

    def forward(
        self, queries: Tensor, keys: Tensor, query_pe: Tensor, key_pe: Tensor, mask_feat: Tensor
    ) -> Tuple[Tensor, Tensor]:


        # Cross attention block, tokens attending to image embedding
        q = queries + query_pe
        k = keys + key_pe
        attn_out = self.cross_attn_token_to_image(q=q, k=k, v=keys, mask_feat=mask_feat)
        queries = queries + self.dropout(attn_out) 
        queries = self.norm2(queries)

        # Self attention block
        if self.skip_first_layer_pe:
            queries = self.self_attn(q=queries, k=queries, v=queries)
        else:
            q = queries + query_pe
            attn_out = self.self_attn(q=q, k=q, v=queries)
            queries = queries + attn_out
        queries = self.norm1(queries)

        # MLP block
        mlp_out = self.mlp(queries)
        queries = queries + mlp_out
        queries = self.norm3(queries)

        # Cross attention block, image embedding attending to tokens
        q = queries + query_pe
        k = keys + key_pe
        attn_out = self.cross_attn_image_to_token(q=k, k=q, v=queries, mask_feat=mask_feat)
        keys = keys + attn_out
        keys = self.norm4(keys)

        return queries, keys


class Attention(nn.Module):
    """
    An attention layer that allows for downscaling the size of the embedding
    after projection to queries, keys, and values.
    """

    def __init__(
        self,
        embedding_dim: int,
        num_heads: int,
        downsample_rate: int = 1,
        dropout=0.0,
    ) -> None:
        super().__init__()
        self.embedding_dim = embedding_dim
        self.internal_dim = embedding_dim // downsample_rate
        self.num_heads = num_heads
        assert self.internal_dim % num_heads == 0, "num_heads must divide embedding_dim."

        self.q_proj = nn.Linear(embedding_dim, self.internal_dim)
        self.k_proj = nn.Linear(embedding_dim, self.internal_dim)
        self.v_proj = nn.Linear(embedding_dim, self.internal_dim)
        self.out_proj = nn.Linear(self.internal_dim, embedding_dim)
        self.dropout = nn.Dropout(dropout)

    def _separate_heads(self, x: Tensor, num_heads: int) -> Tensor:
        b, n, c = x.shape
        x = x.reshape(b, n, num_heads, c // num_heads)
        return x.transpose(1, 2)  # B x N_heads x N_tokens x C_per_head

    def _recombine_heads(self, x: Tensor) -> Tensor:
        b, n_heads, n_tokens, c_per_head = x.shape
        x = x.transpose(1, 2)
        return x.reshape(b, n_tokens, n_heads * c_per_head)  # B x N_tokens x C

    def forward(self, q: Tensor, k: Tensor, v: Tensor) -> Tensor:
        # Input projections
        q = self.q_proj(q)
        k = self.k_proj(k)
        v = self.v_proj(v)

        # Separate into heads
        q = self._separate_heads(q, self.num_heads)
        k = self._separate_heads(k, self.num_heads)
        v = self._separate_heads(v, self.num_heads)

        # Attention
        _, _, _, c_per_head = q.shape
        attn = q @ k.permute(0, 1, 3, 2)  # B x N_heads x N_tokens x N_tokens
        attn = attn / math.sqrt(c_per_head)
        attn = torch.softmax(attn, dim=-1)

        # Get output
        out = attn @ v
        out = self._recombine_heads(out)
        out = self.out_proj(out)

        return out


class Attention2(nn.Module):
    """
    An attention layer that allows for downscaling the size of the embedding
    after projection to queries, keys, and values.
    """

    def __init__(
        self,
        embedding_dim: int,
        num_heads: int,
        downsample_rate: int = 1,
    ) -> None:
        super().__init__()
        self.embedding_dim = embedding_dim
        self.internal_dim = embedding_dim // downsample_rate
        self.num_heads = num_heads
        assert self.internal_dim % num_heads == 0, "num_heads must divide embedding_dim."

        self.q_proj = nn.Linear(embedding_dim, self.internal_dim)
        self.k_proj = nn.Linear(embedding_dim, self.internal_dim)
        self.v_proj = nn.Linear(embedding_dim, self.internal_dim)
        self.out_proj = nn.Linear(self.internal_dim, embedding_dim)
        self.norm1 = nn.LayerNorm(196)
        self.norm2 = nn.LayerNorm(9)
        self.norm3 = nn.LayerNorm(1024)

    def _separate_heads(self, x: Tensor, num_heads: int) -> Tensor:
        b, n, c = x.shape
        x = x.reshape(b, n, num_heads, c // num_heads)
        return x.transpose(1, 2)  # B x N_heads x N_tokens x C_per_head

    def _recombine_heads(self, x: Tensor) -> Tensor:
        b, n_heads, n_tokens, c_per_head = x.shape
        x = x.transpose(1, 2)
        return x.reshape(b, n_tokens, n_heads * c_per_head)  # B x N_tokens x C

    def forward(self, q: Tensor, k: Tensor, v: Tensor, mask_feat: Tensor) -> Tensor:
        # Input projections
        q = self.q_proj(q)
        k = self.k_proj(k)
        v = self.v_proj(v)

        # Separate into heads
        q = self._separate_heads(q, self.num_heads)
        k = self._separate_heads(k, self.num_heads)
        v = self._separate_heads(v, self.num_heads)

        # Attention
        _, _, _, c_per_head = q.shape
        attn = q @ k.permute(0, 1, 3, 2)  # B x N_heads x N_tokens x N_tokens
        mask_feat = mask_feat.unsqueeze(1)
        # mask_feat = (-1)/mask_feat + 1
        mask_feat = torch.repeat_interleave(mask_feat, self.num_heads, dim=1)
        
        attn = attn / math.sqrt(c_per_head)
        attn[torch.where(attn.sum(-1) == attn.shape[-1])] = False
        attn = torch.softmax(attn, dim=-1)
        if attn.shape[3] == mask_feat.shape[3]:
            if attn.shape[-1]==196:
                attn = torch.mul(attn,mask_feat)
            elif attn.shape[-1]==1024:
                attn = torch.mul(attn,mask_feat)
        else: 
            ms = mask_feat.transpose(2,3)
            attn = torch.mul(attn,ms)

        # Get output
        out = attn @ v
        out = self._recombine_heads(out)
        out = self.out_proj(out)

        return out

class CrossAttentionLayer(nn.Module):

    def __init__(self, d_model, nhead, dropout=0.0,
                 activation="relu", normalize_before=False):
        super().__init__()
        self.multihead_attn = nn.MultiheadAttention(d_model, nhead, dropout=dropout)

        self.norm = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)

        self.activation = _get_activation_fn(activation)
        self.normalize_before = normalize_before

        self._reset_parameters()
    
    def _reset_parameters(self):
        for p in self.parameters():
            if p.dim() > 1:
                nn.init.xavier_uniform_(p)

    def with_pos_embed(self, tensor, pos: Optional[Tensor]):
        return tensor if pos is None else tensor + pos

    def forward_post(self, tgt, memory,
                     memory_mask: Optional[Tensor] = None,
                     memory_key_padding_mask: Optional[Tensor] = None,
                     pos: Optional[Tensor] = None,
                     query_pos: Optional[Tensor] = None):
        tgt2 = self.multihead_attn(query=self.with_pos_embed(tgt, query_pos),
                                   key=self.with_pos_embed(memory, pos),
                                   value=memory, attn_mask=memory_mask,
                                   key_padding_mask=memory_key_padding_mask)[0]
        tgt = tgt + self.dropout(tgt2)
        tgt = self.norm(tgt)
        
        return tgt

    def forward_pre(self, tgt, memory,
                    memory_mask: Optional[Tensor] = None,
                    memory_key_padding_mask: Optional[Tensor] = None,
                    pos: Optional[Tensor] = None,
                    query_pos: Optional[Tensor] = None):
        tgt2 = self.norm(tgt)
        tgt2 = self.multihead_attn(query=self.with_pos_embed(tgt2, query_pos),
                                   key=self.with_pos_embed(memory, pos),
                                   value=memory, attn_mask=memory_mask,
                                   key_padding_mask=memory_key_padding_mask)[0]
        tgt = tgt + self.dropout(tgt2)

        return tgt

    def forward(self, tgt, memory,
                memory_mask: Optional[Tensor] = None,
                memory_key_padding_mask: Optional[Tensor] = None,
                pos: Optional[Tensor] = None,
                query_pos: Optional[Tensor] = None):
        if self.normalize_before:
            return self.forward_pre(tgt, memory, memory_mask,
                                    memory_key_padding_mask, pos, query_pos)
        return self.forward_post(tgt, memory, memory_mask,
                                 memory_key_padding_mask, pos, query_pos)
