import os
import numpy as np
import h5py

def convert_npz_to_h5(npz_folder, output_h5_path):
    """
    Convert NPZ files in a folder to an HDF5 format.
    NPZ files should have filenames listed in a txt file with the expected `.npz` extension.

    :param npz_folder: Folder containing the NPZ files.
    :param output_h5_path: Path to save the converted HDF5 file.
    """
    # 创建一个 HDF5 文件
    with h5py.File(output_h5_path, 'w') as hf:
        # 获取所有 .npz 文件
        npz_files = [f for f in os.listdir(npz_folder) if f.endswith('.npz')]

        for npz_file in npz_files:
            npz_file_path = os.path.join(npz_folder, npz_file)
            # 加载 .npz 文件
            data = np.load(npz_file_path)
            
            # 假设每个 .npz 文件包含 'image' 和 'label' 两个数组
            # 如果有其他数据，也可以添加类似的处理方式
            image_data = data.get('image')
            label_data = data.get('label')

            if image_data is not None and label_data is not None:
                # 存储图像数据和标签
                # 如果你不想修改数据维度，可以直接存储
                hf.create_dataset(npz_file.replace('.npz', '/image'), data=image_data)
                hf.create_dataset(npz_file.replace('.npz', '/label'), data=label_data)
                print(f"Converted {npz_file} to HDF5 format.")

            else:
                print(f"Warning: Missing 'image' or 'label' in {npz_file}, skipping file.")

        print(f"Conversion completed. HDF5 saved to {output_h5_path}.")

def add_npz_extension_from_txt(txt_file_path, folder_path):
    """
    Modify the file paths in the provided txt file to add '.npz' extensions to filenames.
    This ensures that each filename is correctly matched when loading from the disk.
    
    :param txt_file_path: Path to the text file listing the filenames.
    :param folder_path: Path to the folder containing the NPZ files.
    """
    with open(txt_file_path, 'r') as f:
        filenames = f.readlines()

    filenames = [filename.strip() + '.npz' for filename in filenames]

    with open(txt_file_path, 'w') as f:
        for filename in filenames:
            if os.path.exists(os.path.join(folder_path, filename)):
                f.write(filename + '\n')
            else:
                print(f"File {filename} does not exist in {folder_path}. Skipping.")

if __name__ == "__main__":
    # 转换 npz 文件夹到 h5 文件
    npz_folder = 'train_npz_new_224'
    output_h5_path = '/home/russ/ava/H-SAM/testset/test_vol_h5.h5'  # 这里添加 .h5 后缀
    convert_npz_to_h5(npz_folder, output_h5_path)
    
    # 如果需要修改 txt 文件中的文件名（添加后缀）
    txt_file_path = 'test_vol.txt'
    add_npz_extension_from_txt(txt_file_path, npz_folder)

