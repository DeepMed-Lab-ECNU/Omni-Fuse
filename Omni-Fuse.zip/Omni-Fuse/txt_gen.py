import os
import glob

npz_folder = 'data/train_npz'  # 替换为你的 npz 文件夹路径
train_txt_path = 'train.txt'      # 输出 train.txt 文件路径

npz_files = sorted(glob.glob(os.path.join(npz_folder, '*.npz')))


with open(train_txt_path, 'w') as f:
    for npz_file in npz_files:
        file_name = os.path.splitext(os.path.basename(npz_file))[0]
        f.write(file_name + '\n')

print(f"train.txt 已生成，文件路径：{train_txt_path}")